<?php
require 'connect.php';

// Read data
$sql = "SELECT * FROM tb_pengisian";
$result = $conn->query($sql);




// Delete data
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM tb_pengisian WHERE id='$id'";
    $conn->query($sql);

    header('Location: menampilkan.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>CRUD PHP</title>
    <style>
           body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h2 {
            margin-bottom: 15px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        table, th, td {
            border: 1px solid #ccc;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            background-color: #4CAF50;
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
        }

        a:hover {
            background-color: #45a049;
        }

        form {
            max-width: 400px;
            margin: 20px 0;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        input[type="reset"] {
            background-color: #dc3545;
            margin-left: 10px;
        }

        input[type="reset"]:hover {
            background-color: #b32d41;
        }
    
    </style>
</head>
<body>
    <h2>Data Pemesanan Tiket</h2>
    <table border="1">
        <tr>
            <th>Nama</th>
            <th>Umur</th>
            <th>Nik</th>
            <th>Alamat</th>
            <th>Nama Kapal</th>
            <th>Pengeditan</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['age']; ?></td>
                <td><?php echo $row['nik']; ?></td>
                <td><?php echo $row['alamat']; ?></td>
                <td><?php echo $row['nama_kapal']; ?></td>
                <td>
                    <a href="edit.php?update=edit&id=<?php echo $row['id']; ?>">Edit</a>
                    <a href="menampilkan.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
    </table></br>

            <a href="crud.php" class="crud-button">Tambah Data</a>
            <a href="dashboard.html">kembali ke dashboard</a>
</body>
</html>
