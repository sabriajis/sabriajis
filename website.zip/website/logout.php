<?php
// Mulai sesi untuk mengakses data sesi pengguna
session_start();

// Hapus semua data sesi untuk menghapus informasi login pengguna
session_unset();

// Hancurkan sesi
session_destroy();

// Redirect kembali ke halaman login setelah berhasil log out
header('Location: login.html');
exit();
?>
