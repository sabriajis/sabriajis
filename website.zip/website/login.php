<?php
    require 'connect.php';
    session_start();

    $username = $_POST["username"];
    $password = $_POST["password"];

    // Anggap login berhasil, simpan username dalam sesi
    $_SESSION["username"] = $username;

    $query_sql = "SELECT * FROM  regis where username = ? AND password = ?";
    $stmt = mysqli_prepare($conn, $query_sql);

    // Periksa apakah pernyataan berhasil disiapkan
    if (!$stmt) {
        die("Error: " . mysqli_error($conn));
    }
    
    // mengikat parameter ke pernyataan
    mysqli_stmt_bind_param($stmt, "si", $username, $password);
    
    // Jalankan pernyataan
    mysqli_stmt_execute($stmt);
    
    // Dapatkan hasil dari pernyataan yang dijalankan
    $resul = mysqli_stmt_get_result($stmt);

    if(mysqli_num_rows($resul) > 0){
        header('Location: dashboard.html?status=sukses');
    }else{
        header('Location: login.html?status=gagal');
    }


?>