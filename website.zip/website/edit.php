<?php
// error_reporting();
require 'connect.php';

// Process edit data
if ($_SERVER['REQUEST_METHOD'] === 'POST') { // Kode atau aksi yang akan dieksekusi jika metode permintaan adalah POST.
//"POST" digunakan ketika klien ingin mengirim data ke server, seperti ketika mengirimkan formulir.
    $id = $_POST['id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $nik = $_POST['nik'];
    $alamat = $_POST['alamat'];
    $nama_kapal = $_POST['nama_kapal'];

    $sql = "UPDATE tb_pengisian SET name='$name', age='$age',nik='$nik',alamat='$alamat',nama_kapal='$nama_kapal' WHERE id='$id'";
    $conn->query($sql);

    header('Location: menampilkan.php');
    exit();
} else {
    // Metode "GET" digunakan ketika klien ingin mendapatkan data dari server, sementara metode 
    // memanggil data tabel diatas
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        $sql = "SELECT * FROM tb_pengisian WHERE id='$id'"; // menampilkan query di mysql
        $result = $conn->query($sql);
        $row = $result->fetch_assoc(); // memanggil array atau data dia atas

        if (isset($row['name'])) {
            $name = $row['name'];
            $age = $row['age'];
            $nik = $row['nik'];
            $alamat = $row['alamat'];
            $nama_kapal = $row['nama_kapal'];
        } else {
            $error = "Data tidak ditemukan";
        }
    } else {
        $error = "Data tidak ditemukan";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>update data</title>
    <style>
        <style>body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: grey;
            box-sizing: border-box;
        }

        h2 {
            margin-bottom: 15px;
        }



        a:hover {
            background-color: #45a049;
        }

        form {
            max-width: 400px;
            margin: 20px 0;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        input[type="reset"] {
            background-color: #dc3545;
            margin-left: 10px;
        }

        input[type="reset"]:hover {
            background-color: #b32d41;
        }
    </style>
    </style>
</head>

<body>
    <?php if (isset($error)) { ?>
        <h2>Error:
            <?php echo $error; ?>
        </h2>
    <?php } else { ?>
        <h2 align="center">Edit Pemesanan Tiket</h2>
        <form method="post" action="edit.php">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <label>Nama:</label>
            <input type="text" name="name" value="<?php echo $name; ?>" required>
            <br>
            <label>Umur:</label>
            <input type="number" name="age" value="<?php echo $age; ?>" required>
            <br>
            <label>Nik:</label>
            <input type="text" name="nik" value="<?php echo $nik; ?>" required>
            <br>
            <label>Alamat:</label>
            <input type="text" name="alamat" value="<?php echo $alamat; ?>" required>
            <br>
            <label>Nama Kapal:</label>
            <?php $nama_kapal = $row['nama_kapal']; ?>
            <select name="nama_kapal" required>
                <option value="tol_nusantara" <?php echo ($nama_kapal == 'tol_nusantara') ? 'selected' : ''; ?>>Tol Nusantara
                </option>
                <option value="tol_makasar" <?php echo ($nama_kapal == 'tol_makasar') ? 'selected' : ''; ?>>Tol Makasar
                </option>
                <option value="fery" <?php echo ($nama_kapal == 'fery') ? 'selected' : ''; ?>>Fery</option>
                <option value="fery_makasar" <?php echo ($nama_kapal == 'fery_makasar') ? 'selected' : ''; ?>>Fery Makasar
                </option>
            </select>
    </br>
            <input type="submit" name="update" value="Update">
        </form>
    <?php } ?>
</body>

</html>