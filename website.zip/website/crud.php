<?php
require 'connect.php';


// Create data
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $nik = $_POST['nik'];
    $alamat = $_POST['alamat'];
    $nama_kapal = $_POST['nama_kapal'];

    $sql = "INSERT INTO tb_pengisian (name, age,nik,alamat,nama_kapal) VALUES ('$name', '$age','$nik','$alamat','$nama_kapal')";
    $conn->query($sql);

    header('Location: menampilkan.php');
    exit();
}



?>

<!DOCTYPE html>
<html>
<head>
    <title>CRUD PHP</title>
    <style>
           body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h2 {
            margin-bottom: 15px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        table, th, td {
            border: 1px solid #ccc;
            padding: 8px;
        }

        th {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            background-color: #4CAF50;
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
        }

        a:hover {
            background-color: #45a049;
        }

        form {
            max-width: 400px;
            margin: 20px 0;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        input[type="reset"] {
            background-color: #dc3545;
            margin-left: 10px;
        }

        input[type="reset"]:hover {
            background-color: #b32d41;
        }
    
    </style>
</head>
<body>
   

    <h2>Tambah Pemesanan Tiket</h2>
    <form method="post" action="crud.php">
        <label>Nama:</label>
        <input type="text" name="name" required>
    </br>
        <label>Umur:</label>
        <input type="number" name="age" required>
    </br>
        <label>NIK:</label>
        <input type="text" name="nik" required>
    </br>
        <label>Alamat:</label>
        <input type="text" name="alamat" required>
    </br>
    <label>Nama Kapal:</label>
        <select type="enum" name="nama_kapal" required>
        <option value="tol_nusantara">Tol Nusantara</option>
        <option value="tol_makasar">Tol Makasar</option>
        <option value="fery">Fery</option>
        <option value="fery_makasar">Fery Makasar</option>
        </select>
    </br>
        <input type="submit" name="submit" value="Simpan">
        <a href="dashboard.html">kembali ke dashboard</a>
    </form>
    
    
</body>
</html>
