<?php
 error_reporting(E_ALL);
    require 'connect.php';
    $nama_panjang = $_POST["nama_panjang"];
    $name = $_POST["name"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Periksa apakah username sudah ada dalam database
    $check_query = "SELECT * FROM regis WHERE username = ?";
    $check_stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($check_stmt, "s", $username);
    mysqli_stmt_execute($check_stmt);
    $existing_user = mysqli_stmt_get_result($check_stmt);

    if (mysqli_num_rows($existing_user) > 0) {
        // Jika username sudah ada, pendaftaran ditolak
        header("Location: regis.html?status=gagal");
        exit(); // Menghentikan eksekusi lebih lanjut agar pendaftaran tidak dilanjutkan
    }

    $query_sql = "INSERT INTO regis(nama_panjang,name,username,password)values(?,?,?,?)";
    $stmt = mysqli_prepare($conn, $query_sql);

    // Periksa apakah pernyataan berhasil diprepare
    if (!$stmt) {
        die("Error: " . mysqli_error($conn));
    }
    
    // Mengikatkan nilai-nilai ke dalam pernyataan INSERT
    mysqli_stmt_bind_param($stmt, "ssss", $nama_panjang, $name, $username, $password);

    if(mysqli_stmt_execute($stmt)){
        header("Location: login.html");
    }else{
        echo "pendaftaran gagal :" . mysqli_stmt_error($stmt);
    }
    
?>